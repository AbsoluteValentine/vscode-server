#!/usr/bin/with-contenv /bin/bash

export HOME="/home/test"
export USER="test"
export SHELL="/bin/bash"

SCRIPT=$(realpath "$0")
SDIR=$(dirname "${SCRIPT}")

cd $SDIR;

exec s6-envuidgid -i test s6-applyuidgid -U $SDIR/verifyRun.sh "$1"