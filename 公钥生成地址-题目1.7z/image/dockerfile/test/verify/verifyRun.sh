#!/bin/bash

set -ex

cleanup() {
    if [[ -d "${TMPD}" ]]; then
        rm -rf "${TMPD}";
    fi
}

SCRIPT=$(realpath "$0")
SDIR=$(dirname "${SCRIPT}")

trap cleanup EXIT;

TMPD=$(mktemp -d)

cd "${TMPD}";

cp $SDIR/generateAddress_test.go $SDIR/go.mod $SDIR/go.sum ./;
cp ~user/workspace/generateAddress.go ./;

go test -v -run "$1"